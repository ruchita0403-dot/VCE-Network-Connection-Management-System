package java_ass2;

import java.awt.*;
import java.awt.event.*;
import java.sql.*;
public class ViewOperating_system extends Frame 
{
	Button updateOperating_systemButton;
	List Operating_systemList;
	TextField osnameText, versionText, vendorText;
	TextArea errorText;
	Connection connection;
	Statement statement;
	ResultSet rs;
	
	public ViewOperating_system() 
	{
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectToDB();
	}

	public void connectToDB() 
    {
		try 
		{
		  connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","ruchi","04032001");
		  statement = connection.createStatement();

		} 
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }
	
	private void loadOperating_system() 
	{	   
		try 
		{
		  rs = statement.executeQuery("SELECT * FROM Operating_system");
		  while (rs.next()) 
		  {
			  Operating_systemList.add(rs.getString("OSNAME"));
		  }
		} 
		catch (SQLException e) 
		{ 
		  displaySQLErrors(e);
		}
	}
	
	public void buildGUI() 
	{		
		Operating_systemList = new List(6);
		loadOperating_system();
		add(Operating_systemList);
		
		//When a list item is selected populate the text fields
		Operating_systemList.addItemListener(new ItemListener()
		{
			public void itemStateChanged(ItemEvent e) 
			{
				try 
				{
					rs = statement.executeQuery("SELECT * FROM Operating_system");
					while (rs.next()) 
					{
						if (rs.getString("OSNAME").equals(Operating_systemList.getSelectedItem()))
						break;
					}
					if (!rs.isAfterLast()) 
					{
						osnameText.setText(rs.getString("OSNAME"));
						versionText.setText(rs.getString("VERSION"));
						vendorText.setText(rs.getString("VENDOR"));
					}
				} 
				catch (SQLException selectException) 
				{
					displaySQLErrors(selectException);
				}
			}
		});		
		
	    
		//Handle Update Operating_system Button
		updateOperating_systemButton = new Button("Update Operating_system");
		updateOperating_systemButton.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e) 
			{
				try 
				{
					Statement statement = connection.createStatement();
					int i = statement.executeUpdate("UPDATE Operating_system "
					+ "SET version='" + versionText.getText() + "', "
					+ "vendor='" + vendorText.getText() + "' WHERE osname ='"
					+ Operating_systemList.getSelectedItem()+"'");
					errorText.append("\nUpdated " + i + " rows successfully");
					Operating_systemList.removeAll();
					loadOperating_system();
				} 
				catch (SQLException insertException) 
				{
					displaySQLErrors(insertException);
				}
			}
		});
		
		osnameText = new TextField(15);
		osnameText.setEditable(false);
		versionText = new TextField(15);
		vendorText = new TextField(15);
		
		errorText = new TextArea(10, 40);
		errorText.setEditable(false);

		Panel first = new Panel();
		first.setLayout(new GridLayout(4, 2));
		first.add(new Label("Operating_system_name:"));
		first.add(osnameText);
		first.add(new Label("Version:"));
		first.add(versionText);
		first.add(new Label("Vendor:"));
		first.add(vendorText);
		
		Panel second = new Panel(new GridLayout(4, 1));
		second.add(updateOperating_systemButton);
		
		Panel third = new Panel();
		third.add(errorText);
		
		add(first);
		add(second);
		add(third);
	    
		setTitle("Update Operating_system");
		setSize(500, 600);
		setLayout(new FlowLayout());
		setVisible(true);
		
	}

	private void displaySQLErrors(SQLException e) 
	{
		errorText.append("\nSQLException: " + e.getMessage() + "\n");
		errorText.append("SQLState:     " + e.getSQLState() + "\n");
		errorText.append("VendorError:  " + e.getErrorCode() + "\n");
	}

	public static void main(String[] args) 
	{
		ViewOperating_system upb = new ViewOperating_system();

		upb.addWindowListener(new WindowAdapter(){
		  public void windowClosing(WindowEvent e) 
		  {
			System.exit(0);
		  }
		});
		
		upb.buildGUI();
	}
}
