package java_ass2;

import java.awt.*; 
import java.awt.event.*;

public class NetworkCompany extends Frame implements ActionListener{
	  
	String msg = ""; 
	Label ll;
	
	DeleteBlock_Computers dbc;
	DeleteBlock_Routers dbr;
	DeleteBlock_Server dbs;
	DeleteBlock db;
	DeleteServer ds;
	DeleteRouters dr; 
	DeleteOperating_system dos;
	DeleteInternet di;
	DeleteComputers dc;
	DeleteComputers_Operating_system dcos;
	DeleteInternet_Server dis;
	
	
	MakeBlock_Computers mbc;
	MakeBlock_Routers mbr;
	MakeBlock_Server mbs;
	MakeComputers_Operating_system mcos;
	MakeInternet_Server mis;
	InsertBlock ib;
	InsertServer is;
	InsertRouters ir;
	InsertOperating_system ios;
	InsertInternet ii;
	InsertComputers ic;
	
	
	ViewBlock_Computers vbc;
	ViewBlock_Routers vbr;
	ViewBlock_Server vbs;
	ViewBlock vb;
	ViewServer vs;
	ViewRouters vr;
	ViewOperating_system vos;
	ViewInternet vi;
	ViewComputers vc;
	ViewComputers_Operating_system vcos;
	ViewInternet_Server vis;
	
	NetworkCompany() 
	{ 
		ll = new Label();
		ll.setAlignment(Label.CENTER);  
		ll.setBounds(90,250,250,100); 			
		ll.setText("Welcome to XYZ Network Company");
		add(ll);
	 
		// create menu bar and add it to frame 
		MenuBar mbar = new MenuBar(); 
		setMenuBar(mbar); 
	 
		// create the menu items and add it to Menu
		Menu block = new Menu("Block"); 
		MenuItem item1, item2, item3; 
		block.add(item1 = new MenuItem("Insert Block")); 
		block.add(item2 = new MenuItem("View Block")); 
		block.add(item3 = new MenuItem("Delete Block")); 
		mbar.add(block);  
		
		Menu computer = new Menu("Computers"); 
		MenuItem item4, item5, item6; 
		computer.add(item4 = new MenuItem("Insert Computers")); 
		computer.add(item5 = new MenuItem("View Computers")); 
		computer.add(item6 = new MenuItem("Delete Computers"));  
		mbar.add(computer); 
		
		Menu router = new Menu("Routers"); 
		MenuItem item7, item8, item9; 
		router.add(item7 = new MenuItem("Insert Routers")); 
		router.add(item8 = new MenuItem("View Routers")); 
		router.add(item9 = new MenuItem("Delete Routers"));  
		mbar.add(router);
		
		Menu server = new Menu("Server"); 
		MenuItem item10, item11, item12; 
		server.add(item10 = new MenuItem("Insert Server")); 
		server.add(item11 = new MenuItem("View Server")); 
		server.add(item12 = new MenuItem("Delete Server"));  
		mbar.add(server);
		
		Menu ops = new Menu("Operating_system"); 
		MenuItem item13, item14, item15; 
		ops.add(item13 = new MenuItem("Insert Operating_system")); 
		ops.add(item14 = new MenuItem("View Operating_system")); 
		ops.add(item15 = new MenuItem("Delete Operating_system"));  
		mbar.add(ops);
		
		Menu internet = new Menu("Internet"); 
		MenuItem item16, item17, item18; 
		internet.add(item16 = new MenuItem("Insert Internet")); 
		internet.add(item17 = new MenuItem("View Internet")); 
		internet.add(item18 = new MenuItem("Delete Internet"));  
		mbar.add(internet);
				
		Menu blco = new Menu("Block_Computers"); 
		MenuItem item19, item20, item21; 
		blco.add(item19 = new MenuItem("Make Block_Computers")); 
		blco.add(item20 = new MenuItem("View Block_Computers")); 
		blco.add(item21 = new MenuItem("Delete Block_Computers")); 
		mbar.add(blco); 
		
		Menu blro = new Menu("Block_Routers"); 
		MenuItem item22, item23, item24; 
		blro.add(item22 = new MenuItem("Make Block_Routers")); 
		blro.add(item23 = new MenuItem("View Block_Routers")); 
		blro.add(item24 = new MenuItem("Delete Block_Routers")); 
		mbar.add(blro); 
		
		Menu blse = new Menu("Block_Server"); 
		MenuItem item25, item26, item27; 
		blse.add(item25 = new MenuItem("Make Block_Server")); 
		blse.add(item26 = new MenuItem("View Block_Server")); 
		blse.add(item27 = new MenuItem("Delete Block_Server")); 
		mbar.add(blse); 
		
		Menu cos = new Menu("Computers_Operating_system"); 
		MenuItem item28, item29, item30; 
		cos.add(item28 = new MenuItem("Make Computers_Operating_system")); 
		cos.add(item29 = new MenuItem("View Computers_Operating_system")); 
		cos.add(item30 = new MenuItem("Delete Computers_Operating_system")); 
		mbar.add(cos); 
		
		Menu inse = new Menu("Internet_Server"); 
		MenuItem item31, item32, item33; 
		inse.add(item31 = new MenuItem("Make Internet_Server")); 
		inse.add(item32 = new MenuItem("View Internet_Server")); 
		inse.add(item33 = new MenuItem("Delete Internet_Server")); 
		mbar.add(inse); 
		
		
		// register listeners
		item1.addActionListener(this); 
		item2.addActionListener(this); 
		item3.addActionListener(this); 
		item4.addActionListener(this); 
		item5.addActionListener(this); 
		item6.addActionListener(this); 
		item7.addActionListener(this); 
		item8.addActionListener(this); 
		item9.addActionListener(this);
		item10.addActionListener(this);
		item11.addActionListener(this); 
		item12.addActionListener(this); 
		item13.addActionListener(this); 
		item14.addActionListener(this); 
		item15.addActionListener(this); 
		item16.addActionListener(this); 
		item17.addActionListener(this); 
		item18.addActionListener(this); 
		item19.addActionListener(this);
		item20.addActionListener(this);
		item21.addActionListener(this); 
		item22.addActionListener(this); 
		item23.addActionListener(this); 
		item24.addActionListener(this); 
		item25.addActionListener(this); 
		item26.addActionListener(this); 
		item27.addActionListener(this); 
		item28.addActionListener(this); 
		item29.addActionListener(this);
		item30.addActionListener(this);
		item31.addActionListener(this); 
		item32.addActionListener(this); 
		item33.addActionListener(this); 
				
		 // Anonymous inner class which extends WindowAdaptor to handle the Window event: windowClosing  
		addWindowListener(new WindowAdapter(){
			public void windowClosing(WindowEvent we) 
			{ 
				System.exit(0);	
			} 
		}); 
		
		//Frame properties
		setTitle("XYZ Network Company"); 
		Color clr = new Color(200, 100, 150);
		setBackground(clr); 
		setFont(new Font("SansSerif", Font.BOLD, 14)); 
		setLayout(null);
		setSize(1100, 800); 
		setVisible(true);	
		
	  }   
	  
	  public void actionPerformed(ActionEvent ae) 
	  {
		  String arg = ae.getActionCommand(); 
		  if(arg.equals("Insert Block"))
		  {
			ib = new InsertBlock();
			ib.addWindowListener(new WindowAdapter()
			{
				public void windowClosing(WindowEvent e) 
				{
					ib.dispose();
				}
			});		
			ib.buildGUI();	
		 }			
		 
		 else if(arg.equals("View Block")) 
		 {
			vb = new ViewBlock();
			vb.addWindowListener(new WindowAdapter(){
			public void windowClosing(WindowEvent e) 
		    {
				vb.dispose();
			}
			});		
			vb.buildGUI();		 
		 }
		 
		 else if(arg.equals("Delete Block")) 
		 {
			db = new DeleteBlock();
			db.addWindowListener(new WindowAdapter()
			{
				public void windowClosing(WindowEvent e) 
				{
					db.dispose();
				}
			});		
			db.buildGUI();		 
		 }
		 else if(arg.equals("Insert Computers"))
		  {
			ic = new InsertComputers();
			ic.addWindowListener(new WindowAdapter()
			{
				public void windowClosing(WindowEvent e) 
				{
					ic.dispose();
				}
			});		
			ic.buildGUI();	
		 }			
		 
		 else if(arg.equals("View Computers")) 
		 {
			vc = new ViewComputers();
			vc.addWindowListener(new WindowAdapter(){
			public void windowClosing(WindowEvent e) 
		    {
				vc.dispose();
			}
			});		
			vc.buildGUI();		 
		 }
		 
		 else if(arg.equals("Delete Computers")) 
		 {
			dc = new DeleteComputers();
			dc.addWindowListener(new WindowAdapter()
			{
				public void windowClosing(WindowEvent e) 
				{
					dc.dispose();
				}
			});		
			dc.buildGUI();		 
		 }

		 else if(arg.equals("Insert Routers"))
		  {
			ir = new InsertRouters();
			ir.addWindowListener(new WindowAdapter()
			{
				public void windowClosing(WindowEvent e) 
				{
					ir.dispose();
				}
			});		
			ir.buildGUI();	
		 }			
		 
		 else if(arg.equals("View Routers")) 
		 {
			vr = new ViewRouters();
			vr.addWindowListener(new WindowAdapter(){
			public void windowClosing(WindowEvent e) 
		    {
				vr.dispose();
			}
			});		
			vr.buildGUI();		 
		 }
		 
		 else if(arg.equals("Delete Routers")) 
		 {
			dr = new DeleteRouters();
			dr.addWindowListener(new WindowAdapter()
			{
				public void windowClosing(WindowEvent e) 
				{
					dr.dispose();
				}
			});		
			dr.buildGUI();		 
		 }

		 else if(arg.equals("Insert Server"))
		  {
			is = new InsertServer();
			is.addWindowListener(new WindowAdapter()
			{
				public void windowClosing(WindowEvent e) 
				{
					is.dispose();
				}
			});		
			is.buildGUI();	
		 }			
		 
		 else if(arg.equals("View Server")) 
		 {
			vs = new ViewServer();
			vs.addWindowListener(new WindowAdapter(){
			public void windowClosing(WindowEvent e) 
		    {
				vs.dispose();
			}
			});		
			vs.buildGUI();		 
		 }
		 
		 else if(arg.equals("Delete Server")) 
		 {
			ds = new DeleteServer();
			ds.addWindowListener(new WindowAdapter()
			{
				public void windowClosing(WindowEvent e) 
				{
					ds.dispose();
				}
			});		
			ds.buildGUI();		 
		 }

		 else if(arg.equals("Insert Operating_system"))
		  {
			ios = new InsertOperating_system();
			ios.addWindowListener(new WindowAdapter()
			{
				public void windowClosing(WindowEvent e) 
				{
					ios.dispose();
				}
			});		
			ios.buildGUI();	
		 }			
		 
		 else if(arg.equals("View Operating_system")) 
		 {
			vos = new ViewOperating_system();
			vos.addWindowListener(new WindowAdapter(){
			public void windowClosing(WindowEvent e) 
		    {
				vos.dispose();
			}
			});		
			vos.buildGUI();		 
		 }
		 
		 else if(arg.equals("Delete Operating_system")) 
		 {
			dos = new DeleteOperating_system();
			dos.addWindowListener(new WindowAdapter()
			{
				public void windowClosing(WindowEvent e) 
				{
					dos.dispose();
				}
			});		
			dos.buildGUI();		 
		 }
		 else if(arg.equals("Insert Internet"))
		  {
			ii = new InsertInternet();
			ii.addWindowListener(new WindowAdapter()
			{
				public void windowClosing(WindowEvent e) 
				{
					ii.dispose();
				}
			});		
			ii.buildGUI();	
		 }			
		 
		 else if(arg.equals("View Internet")) 
		 {
			vi = new ViewInternet();
			vi.addWindowListener(new WindowAdapter(){
			public void windowClosing(WindowEvent e) 
		    {
				vi.dispose();
			}
			});		
			vi.buildGUI();		 
		 }
		 
		 else if(arg.equals("Delete Internet")) 
		 {
			di = new DeleteInternet();
			di.addWindowListener(new WindowAdapter()
			{
				public void windowClosing(WindowEvent e) 
				{
					di.dispose();
				}
			});		
			di.buildGUI();		 
		 }
		 else if(arg.equals("Make Block_Computers"))
		  {
			mbc = new MakeBlock_Computers();
			mbc.addWindowListener(new WindowAdapter()
			{
				public void windowClosing(WindowEvent e) 
				{
					mbc.dispose();
				}
			});		
			mbc.buildGUI();	
		 }			
		 
		 else if(arg.equals("View Block_Computers")) 
		 {
			vbc = new ViewBlock_Computers();
			vbc.addWindowListener(new WindowAdapter(){
			public void windowClosing(WindowEvent e) 
		    {
				vbc.dispose();
			}
			});		
			vbc.buildGUI();		 
		 }
		 
		 else if(arg.equals("Delete Block_Computers")) 
		 {
			dbc = new DeleteBlock_Computers();
			dbc.addWindowListener(new WindowAdapter()
			{
				public void windowClosing(WindowEvent e) 
				{
					dbc.dispose();
				}
			});		
			dbc.buildGUI();		 
		 }
		 else if(arg.equals("Make Block_Routers"))
		  {
			mbr = new MakeBlock_Routers();
			mbr.addWindowListener(new WindowAdapter()
			{
				public void windowClosing(WindowEvent e) 
				{
					mbr.dispose();
				}
			});		
			mbr.buildGUI();	
		 }			
		 
		 else if(arg.equals("View Block_Routers")) 
		 {
			vbr = new ViewBlock_Routers();
			vbr.addWindowListener(new WindowAdapter(){
			public void windowClosing(WindowEvent e) 
		    {
				vbr.dispose();
			}
			});		
			vbr.buildGUI();		 
		 }
		 
		 else if(arg.equals("Delete Block_Routers")) 
		 {
			dbr = new DeleteBlock_Routers();
			dbr.addWindowListener(new WindowAdapter()
			{
				public void windowClosing(WindowEvent e) 
				{
					dbr.dispose();
				}
			});		
			dbr.buildGUI();		 
		 }
		 else if(arg.equals("Make Block_Server"))
		  {
			mbs = new MakeBlock_Server();
			mbs.addWindowListener(new WindowAdapter()
			{
				public void windowClosing(WindowEvent e) 
				{
					mbs.dispose();
				}
			});		
			mbs.buildGUI();	
		 }			
		 
		 else if(arg.equals("View Block_Server")) 
		 {
			vbs = new ViewBlock_Server();
			vbs.addWindowListener(new WindowAdapter(){
			public void windowClosing(WindowEvent e) 
		    {
				vbs.dispose();
			}
			});		
			vbs.buildGUI();		 
		 }
		 
		 else if(arg.equals("Delete Block_Server")) 
		 {
			dbs= new DeleteBlock_Server();
			dbs.addWindowListener(new WindowAdapter()
			{
				public void windowClosing(WindowEvent e) 
				{
					dbs.dispose();
				}
			});		
			dbs.buildGUI();		 
		 }
		 else if(arg.equals("Make Computers_Operating_system"))
		  {
			 mcos = new MakeComputers_Operating_system();
			 mcos.addWindowListener(new WindowAdapter()
			{
				public void windowClosing(WindowEvent e) 
				{
					mcos.dispose();
				}
			});		
			 mcos.buildGUI();	
		 }			
		 
		 else if(arg.equals("View Computers_Operating_system")) 
		 {
			 vcos = new ViewComputers_Operating_system();
			 vcos.addWindowListener(new WindowAdapter(){
			public void windowClosing(WindowEvent e) 
		    {
				vcos.dispose();
			}
			});		
			 vcos.buildGUI();		 
		 }
		 
		 else if(arg.equals("Delete Computers_Operating_system")) 
		 {
			dcos= new DeleteComputers_Operating_system();
			dcos.addWindowListener(new WindowAdapter()
			{
				public void windowClosing(WindowEvent e) 
				{
					dcos.dispose();
				}
			});		
			dcos.buildGUI();		 
		 }
		 else if(arg.equals("Make Internet_Server"))
		  {
			 mis = new MakeInternet_Server();
			 mis.addWindowListener(new WindowAdapter()
			{
				public void windowClosing(WindowEvent e) 
				{
					mis.dispose();
				}
			});		
			 mis.buildGUI();	
		 }			
		 
		 else if(arg.equals("View Internet_Server")) 
		 {
			 vis = new ViewInternet_Server();
			 vis.addWindowListener(new WindowAdapter(){
			public void windowClosing(WindowEvent e) 
		    {
				vis.dispose();
			}
			});		
			 vis.buildGUI();		 
		 }
		 
		 else if(arg.equals("Delete Internet_Server")) 
		 {
			dis= new DeleteInternet_Server();
			dis.addWindowListener(new WindowAdapter()
			{
				public void windowClosing(WindowEvent e) 
				{
					dis.dispose();
				}
			});		
			dis.buildGUI();		 
		 }
		  
	  }
	  public static void main(String ... args)
	  {
			new NetworkCompany();	  
	  }
}