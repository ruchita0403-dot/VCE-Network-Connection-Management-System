package java_ass2;

import java.awt.*;
import java.awt.event.*;
import java.sql.*;
public class DeleteInternet_Server extends Frame 
{
	Button DeleteInternet_ServerButton;
	List Internet_ServerList;
	TextField macText, ipaddressText;
	TextArea errorText;
	Connection connection;
	Statement statement;
	ResultSet rs;
	
	public DeleteInternet_Server() 
	{
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectToDB();
	}

	public void connectToDB() 
    {
		try 
		{
		  connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","ruchi","04032001");
		  statement = connection.createStatement();

		} 
		catch (SQLException connectException)   
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }
	
	private void loadInternet_Server() 
	{	   
		try 
		{
		  rs = statement.executeQuery("SELECT * FROM Internet_Server");
		  while (rs.next()) 
		  {
			  Internet_ServerList.add(rs.getString("mac") + " " + rs.getString("ipadd"));
		  }
		} 
		catch (SQLException e) 
		{ 
		  displaySQLErrors(e);
		}
	}
	
	public void buildGUI() 
	{		
		Internet_ServerList = new List(10);
		loadInternet_Server();
		add(Internet_ServerList);
		
		//When a list item is selected populate the text fields
		Internet_ServerList.addItemListener(new ItemListener()
		{
			public void itemStateChanged(ItemEvent e) 
			{
				try 
				{
					rs = statement.executeQuery("SELECT * FROM Internet_Server");
					while (rs.next()) 
					{
						if ((rs.getString("mac") + " " + rs.getString("ipadd")).equals(Internet_ServerList.getSelectedItem()))
						break;
					}
					if (!rs.isAfterLast()) 
					{
						macText.setText(rs.getString("mac"));
						ipaddressText.setText(rs.getString("ipadd"));
					}
				} 
				catch (SQLException selectException) 
				{
					displaySQLErrors(selectException);
				}
			}
		});		
		
	    
		//Handle Delete Internet_Server Button
		DeleteInternet_ServerButton = new Button("Delete Internet_Server");
		DeleteInternet_ServerButton.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e) 
			{
				try 
				{
					Statement statement = connection.createStatement();
					String intser[]=Internet_ServerList.getSelectedItem().split(" ");
					int i = statement.executeUpdate("DELETE FROM Internet_Server WHERE MAC = '" + intser[0] + "' and ipadd = '" + intser[1] +"'");
					errorText.append("\nDeleted " + i + " rows successfully");
					macText.setText(null);
					ipaddressText.setText(null);
					Internet_ServerList.removeAll();
					loadInternet_Server();
				} 
				catch (SQLException insertException) 
				{
					displaySQLErrors(insertException);
				}
			}
		});
		
		macText = new TextField(15);
		ipaddressText = new TextField(15);
			
		errorText = new TextArea(10, 40);
		errorText.setEditable(false);

		Panel first = new Panel();
		first.setLayout(new GridLayout(4, 2));
		first.add(new Label("MAC:"));
		first.add(macText);
		first.add(new Label("IPAddress:"));
		first.add(ipaddressText);
				
		Panel second = new Panel(new GridLayout(4, 1));
		second.add(DeleteInternet_ServerButton);
		
		Panel third = new Panel();
		third.add(errorText);
		
		add(first);
		add(second);
		add(third);
	    
		setTitle("Remove Internet_Server");
		setSize(450, 600);
		setLayout(new FlowLayout());
		setVisible(true);
		
	}

	

	private void displaySQLErrors(SQLException e) 
	{
		errorText.append("\nSQLException: " + e.getMessage() + "\n");
		errorText.append("SQLState:     " + e.getSQLState() + "\n");
		errorText.append("VendorError:  " + e.getErrorCode() + "\n");
	}

	

	public static void main(String[] args) 
	{
		DeleteInternet_Server dels = new DeleteInternet_Server();

		dels.addWindowListener(new WindowAdapter(){
		  public void windowClosing(WindowEvent e) 
		  {
			System.exit(0);
		  }
		});
		
		dels.buildGUI();
	}
}
