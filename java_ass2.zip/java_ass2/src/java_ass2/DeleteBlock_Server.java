package java_ass2;

import java.awt.*;
import java.awt.event.*;
import java.sql.*;
public class DeleteBlock_Server extends Frame 
{
	Button DeleteBlock_ServerButton;
	List Block_ServerList;
	TextField bnameText, ipaddressText;
	TextArea errorText;
	Connection connection;
	Statement statement;
	ResultSet rs;
	
	public DeleteBlock_Server() 
	{
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectToDB();
	}

	public void connectToDB() 
    {
		try 
		{
		  connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","ruchi","04032001");
		  statement = connection.createStatement();

		} 
		catch (SQLException connectException)   
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }
	
	private void loadBlock_Server() 
	{	   
		try 
		{
		  rs = statement.executeQuery("SELECT * FROM Block_Server");
		  while (rs.next()) 
		  {
			  Block_ServerList.add(rs.getString("BNAME") + "  " + rs.getString("IPADDRESS"));
		  }
		} 
		catch (SQLException e) 
		{ 
		  displaySQLErrors(e);
		}
	}
	
	public void buildGUI() 
	{		
		Block_ServerList = new List(10);
		loadBlock_Server();
		add(Block_ServerList);
		
		//When a list item is selected populate the text fields
		Block_ServerList.addItemListener(new ItemListener()
		{
			public void itemStateChanged(ItemEvent e) 
			{
				try 
				{
					rs = statement.executeQuery("SELECT * FROM Block_Server");
					while (rs.next()) 
					{
						if ((rs.getString("BNAME") + "  " + rs.getString("IPADDRESS")).equals(Block_ServerList.getSelectedItem()))
						break;
					}
					if (!rs.isAfterLast()) 
					{
						ipaddressText.setText(rs.getString("IPADDRESS"));
						bnameText.setText(rs.getString("BNAME"));
					}
				} 
				catch (SQLException selectException) 
				{
					displaySQLErrors(selectException);
				}
			}
		});		
		
	    
		//Handle Delete Block_Server Button
		DeleteBlock_ServerButton = new Button("Delete Block_Server");
		DeleteBlock_ServerButton.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e) 
			{
				try 
				{
					Statement statement = connection.createStatement();
					String bnameip[]=Block_ServerList.getSelectedItem().split("  ");
					int i = statement.executeUpdate("DELETE FROM Block_Server WHERE BNAME = '" +bnameip[0]+"' and ipaddress= '"+bnameip[1]+"'");
					errorText.append("\nDeleted " + i + " rows successfully");
					bnameText.setText(null);
					ipaddressText.setText(null);
					Block_ServerList.removeAll();
					loadBlock_Server();
				} 
				catch (SQLException insertException) 
				{
					displaySQLErrors(insertException);
				}
			}
		});
		
		bnameText = new TextField(15);
		ipaddressText = new TextField(15);
				
		errorText = new TextArea(10, 40);
		errorText.setEditable(false);

		Panel first = new Panel();
		first.setLayout(new GridLayout(4, 2));
		first.add(new Label("Block Name"));
		first.add(bnameText);
		first.add(new Label("IPAddress"));
		first.add(ipaddressText);
				
		Panel second = new Panel(new GridLayout(4, 1));
		second.add(DeleteBlock_ServerButton);
		
		Panel third = new Panel();
		third.add(errorText);
		
		add(first);
		add(second);
		add(third);
	    
		setTitle("Remove Block_Server");
		setSize(450, 600);
		setLayout(new FlowLayout());
		setVisible(true);
		
	}

	

	private void displaySQLErrors(SQLException e) 
	{
		errorText.append("\nSQLException: " + e.getMessage() + "\n");
		errorText.append("SQLState:     " + e.getSQLState() + "\n");
		errorText.append("VendorError:  " + e.getErrorCode() + "\n");
	}

	

	public static void main(String[] args) 
	{
		DeleteBlock_Server dels = new DeleteBlock_Server();

		dels.addWindowListener(new WindowAdapter(){
		  public void windowClosing(WindowEvent e) 
		  {
			System.exit(0);
		  }
		});
		
		dels.buildGUI();
	}
}
