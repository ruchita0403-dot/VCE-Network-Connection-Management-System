package java_ass2;

import java.awt.*;
import java.awt.event.*;
import java.sql.*;
public class ViewInternet extends Frame 
{
	Button updateInternetButton;
	List InternetList;
	TextField macText, htmlText, serv_providerText;
	TextArea errorText;
	Connection connection;
	Statement statement;
	ResultSet rs;
	
	public ViewInternet() 
	{
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectToDB();
	}

	public void connectToDB() 
    {
		try 
		{
		  connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","ruchi","04032001");
		  statement = connection.createStatement();

		} 
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }
	
	private void loadInternet() 
	{	   
		try 
		{
		  rs = statement.executeQuery("SELECT * FROM Internet");
		  while (rs.next()) 
		  {
			  InternetList.add(rs.getString("mac_address"));
		  }
		} 
		catch (SQLException e) 
		{ 
		  displaySQLErrors(e);
		}
	}
	
	public void buildGUI() 
	{		
		InternetList = new List(10);
		loadInternet();
		add(InternetList);
		
		//When a list item is selected populate the text fields
		InternetList.addItemListener(new ItemListener()
		{
			public void itemStateChanged(ItemEvent e) 
			{
				try 
				{
					rs = statement.executeQuery("SELECT * FROM Internet");
					while (rs.next()) 
					{
						if (rs.getString("mac_address").equals(InternetList.getSelectedItem()))
						break;
					}
					if (!rs.isAfterLast()) 
					{
						macText.setText(rs.getString("mac_address"));
						htmlText.setText(rs.getString("HTML"));
						serv_providerText.setText(rs.getString("serv_provider"));
					}
				} 
				catch (SQLException selectException) 
				{
					displaySQLErrors(selectException);
				}
			}
		});		
		
	    
		//Handle Update Internet Button
		updateInternetButton = new Button("Update Internet");
		updateInternetButton.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e) 
			{
				try 
				{
					Statement statement = connection.createStatement();
					int i = statement.executeUpdate("UPDATE Internet "
					+ "SET html='" + htmlText.getText() + "', "
					+ "serv_provider='" + serv_providerText.getText() + "' WHERE mac_address = '"
					+ InternetList.getSelectedItem()+"'");
					errorText.append("\nUpdated " + i + " rows successfully");
					InternetList.removeAll();
					loadInternet();
				} 
				catch (SQLException insertException) 
				{
					displaySQLErrors(insertException);
				}
			}
		});
		
		macText = new TextField(15);
		macText.setEditable(false);
		htmlText = new TextField(15);
		serv_providerText = new TextField(15);
		
		errorText = new TextArea(10, 40);
		errorText.setEditable(false);

		Panel first = new Panel();
		first.setLayout(new GridLayout(4, 2));
		first.add(new Label("MAC:"));
		first.add(macText);
		first.add(new Label("Html:"));
		first.add(htmlText);
		first.add(new Label("Serv_provider:"));
		first.add(serv_providerText);
		
		Panel second = new Panel(new GridLayout(4, 1));
		second.add(updateInternetButton);
		
		Panel third = new Panel();
		third.add(errorText);
		
		add(first);
		add(second);
		add(third);
	    
		setTitle("Update Internet");
		setSize(500, 600);
		setLayout(new FlowLayout());
		setVisible(true);
		
	}

	private void displaySQLErrors(SQLException e) 
	{
		errorText.append("\nSQLException: " + e.getMessage() + "\n");
		errorText.append("SQLState:     " + e.getSQLState() + "\n");
		errorText.append("VendorError:  " + e.getErrorCode() + "\n");
	}

	public static void main(String[] args) 
	{
		ViewInternet upb = new ViewInternet();

		upb.addWindowListener(new WindowAdapter(){
		  public void windowClosing(WindowEvent e) 
		  {
			System.exit(0);
		  }
		});
		
		upb.buildGUI();
	}
}
