package java_ass2;

import java.awt.*;
import java.awt.event.*;
import java.sql.*;
      
public class MakeComputers_Operating_system extends Frame 
{

	Button Computers_Operating_systemButton;
	Choice cidSelect, osnameSelect;
	TextArea errorText;
	Connection connection;
	Statement statement;
	ResultSet rs;
	
	public MakeComputers_Operating_system() 
	{
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectToDB();
	}

	public void connectToDB() 
    {
		try 
		{
		  connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","ruchi","04032001");
		  statement = connection.createStatement();

		} 
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }
	
	private void loadComputers() 
	{
		try 
		{
		  rs = statement.executeQuery("SELECT * FROM Computers");
		  while (rs.next()) 
		  {
			cidSelect.add(rs.getString("CID"));
		  }
		} 
		catch (SQLException e) 
		{ 
		  displaySQLErrors(e);
		}
			
	}
	
	private void loadOperating_system() 
	{
		try 
		{
		  rs = statement.executeQuery("SELECT * FROM Operating_system");
		  while (rs.next()) 
		  {
			osnameSelect.add(rs.getString("OSNAME"));
		  }
		} 
		catch (SQLException e) 
		{ 
		  displaySQLErrors(e);
		}
			
	}
	
	public void buildGUI() 
	{		
	    cidSelect = new Choice();
		loadComputers();
		
		osnameSelect = new Choice();
		loadOperating_system();
		
	    
		//Handle Computers_Operating_system Button
		Computers_Operating_systemButton = new Button("Computers_Operating_system");
		Computers_Operating_systemButton.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent e) 
			{
				try 
				{
				  Statement statement = connection.createStatement();
				  String query= "INSERT INTO Computers_Operating_system VALUES('" + cidSelect.getSelectedItem() + "','" + osnameSelect.getSelectedItem() + "')";
				  int i = statement.executeUpdate(query);
				  errorText.append("\nInserted " + i + " rows successfully");
				} 
				catch (SQLException insertException) 
				{
				  displaySQLErrors(insertException);
				}
			}
		});

		
	
		errorText = new TextArea(10, 40);
		errorText.setEditable(false);

		Panel first = new Panel();
		first.setLayout(new GridLayout(3, 2));
		first.add(new Label("Computer ID:"));
		first.add(cidSelect);
		first.add(new Label("Operating_system:"));
		first.add(osnameSelect);
		
		Panel second = new Panel(new GridLayout(1, 1));
		second.add(Computers_Operating_systemButton);
		
		Panel third = new Panel();
		third.add(errorText);			

		add(first);
		add(second);
		add(third);
	    
		setTitle("Make Computers_Operating_system");
		setSize(500, 600);
		setLayout(new FlowLayout());
		setVisible(true);
		
	}	

	private void displaySQLErrors(SQLException e) 
	{
		errorText.append("\nSQLException: " + e.getMessage() + "\n");
		errorText.append("SQLState:     " + e.getSQLState() + "\n");
		errorText.append("VendorError:  " + e.getErrorCode() + "\n");
	}

	

	public static void main(String[] args) 
	{
		MakeComputers_Operating_system mks = new MakeComputers_Operating_system();

		mks.addWindowListener(new WindowAdapter(){
		  public void windowClosing(WindowEvent e) 
		  {
			System.exit(0);
		  }
		});
		
		mks.buildGUI();
	}
}