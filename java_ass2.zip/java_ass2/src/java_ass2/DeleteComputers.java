package java_ass2;


import java.awt.*;
import java.awt.event.*;
import java.sql.*;
public class DeleteComputers extends Frame 
{
	Button DeleteComputersButton;
	List ComputersIDList;
	TextField cidText, typeText, countText, manufacturerText;
	TextArea errorText;
	Connection connection;
	Statement statement;
	ResultSet rs;
	
	public DeleteComputers() 
	{
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectToDB();
	}

	public void connectToDB() 
    {
		try 
		{
		  connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","ruchi","04032001");
		  statement = connection.createStatement();

		} 
		catch (SQLException connectException)   
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }
	
	private void loadComputers() 
	{	   
		try 
		{
		  rs = statement.executeQuery("SELECT * FROM computers");
		  while (rs.next()) 
		  {
			ComputersIDList.add(rs.getString("CID"));
		  }
		} 
		catch (SQLException e) 
		{ 
		  displaySQLErrors(e);
		}
	}
	
	public void buildGUI() 
	{		
	    ComputersIDList = new List(10);
		loadComputers();
		add(ComputersIDList);
		
		//When a list item is selected populate the text fields
		ComputersIDList.addItemListener(new ItemListener()
		{
			public void itemStateChanged(ItemEvent e) 
			{
				try 
				{
					rs = statement.executeQuery("SELECT * FROM computers");
					while (rs.next()) 
					{
						if (rs.getString("CID").equals(ComputersIDList.getSelectedItem()))
						break;
					}
					if (!rs.isAfterLast()) 
					{
						cidText.setText(rs.getString("CID"));
						typeText.setText(rs.getString("TYPE"));
						countText.setText(rs.getString("COUNT"));
						manufacturerText.setText(rs.getString("MANUFACTURER"));
					}
				} 
				catch (SQLException selectException) 
				{
					displaySQLErrors(selectException);
				}
			}
		});		
		
	    
		//Handle Delete Computers Button
		DeleteComputersButton = new Button("Delete Computers");
		DeleteComputersButton.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e) 
			{
				try 
				{
					Statement statement = connection.createStatement();
					int i = statement.executeUpdate("DELETE FROM computers WHERE CID = '" + ComputersIDList.getSelectedItem()+"'");
					errorText.append("\nDeleted " + i + " rows successfully");
					cidText.setText(null);
					typeText.setText(null);
					countText.setText(null);
					manufacturerText.setText(null);
					ComputersIDList.removeAll();
					loadComputers();
				} 
				catch (SQLException deleteException) 
				{
					displaySQLErrors(deleteException);
				}
			}
		});
		
		cidText = new TextField(15);
		typeText = new TextField(15);
		countText = new TextField(15);
		manufacturerText = new TextField(15);
		
		errorText = new TextArea(10, 40);
		errorText.setEditable(false);

		Panel first = new Panel();
		first.setLayout(new GridLayout(4, 2));
		first.add(new Label("Computers ID:"));
		first.add(cidText);
		first.add(new Label("Type:"));
		first.add(typeText);
		first.add(new Label("Count:"));
		first.add(countText);
		first.add(new Label("Manufacturer:"));
		first.add(manufacturerText);
		
		Panel second = new Panel(new GridLayout(4, 1));
		second.add(DeleteComputersButton);
		
		Panel third = new Panel();
		third.add(errorText);
		
		add(first);
		add(second);
		add(third);
	    
		setTitle("Remove computers");
		setSize(450, 600);
		setLayout(new FlowLayout());
		setVisible(true);
		
	}

	

	private void displaySQLErrors(SQLException e) 
	{
		errorText.append("\nSQLException: " + e.getMessage() + "\n");
		errorText.append("SQLState:     " + e.getSQLState() + "\n");
		errorText.append("VendorError:  " + e.getErrorCode() + "\n");
	}

	

	public static void main(String[] args) 
	{
		DeleteComputers dels = new DeleteComputers();

		dels.addWindowListener(new WindowAdapter(){
		  public void windowClosing(WindowEvent e) 
		  {
			System.exit(0);
		  }
		});
		
		dels.buildGUI();
	}
}
