package java_ass2;

import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class MakeBlock_Computers extends Frame 
{
	Button Block_ComputersButton;
	Choice bnameSelect, cidSelect;
	TextArea errorText;
	Connection connection;
	Statement statement;
	ResultSet rs;
	
	public MakeBlock_Computers() 
	{
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectToDB();
	}

	public void connectToDB() 
    {
		try 
		{
		  connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","ruchi","04032001");
		  statement = connection.createStatement();

		} 
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }
	
	private void loadBlock() 
	{
		try 
		{
		  rs = statement.executeQuery("SELECT * FROM block");
		  while (rs.next()) 
		  {
			bnameSelect.add(rs.getString("BNAME"));
		  }
		} 
		catch (SQLException e) 
		{ 
		  displaySQLErrors(e);
		}
			
	}
	
	private void loadComputers() 
	{
		try 
		{
		  rs = statement.executeQuery("SELECT * FROM Computers");
		  while (rs.next()) 
		  {
			cidSelect.add(rs.getString("CID"));
		  }
		} 
		catch (SQLException e) 
		{ 
		  displaySQLErrors(e);
		}
			
	}
	
	public void buildGUI() 
	{		
	    bnameSelect = new Choice();
		loadBlock();
		
		cidSelect = new Choice();
		loadComputers();
		
	    
		//Handle Block_Computers Button
		Block_ComputersButton = new Button("Block_Computers");
		Block_ComputersButton.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent e) 
			{
				try 
				{
				  Statement statement = connection.createStatement();
				  String query= "INSERT INTO Block_Computers VALUES('" +cidSelect.getSelectedItem() + "', '"+ bnameSelect.getSelectedItem()  +"')";
				  int i = statement.executeUpdate(query);
				  errorText.append("\nInserted " + i + " rows successfully");
				} 
				catch (SQLException insertException) 
				{
				  displaySQLErrors(insertException);
				}
			}
		});

		
		
		errorText = new TextArea(10, 40);
		errorText.setEditable(false);

		Panel first = new Panel();
		first.setLayout(new GridLayout(3, 2));
		first.add(new Label("Computer ID:"));
		first.add(cidSelect);
		first.add(new Label("Block Name:"));
		first.add(bnameSelect);
		
		Panel second = new Panel(new GridLayout(1, 1));
		second.add(Block_ComputersButton);
		
		Panel third = new Panel();
		third.add(errorText);			

		add(first);
		add(second);
		add(third);
	    
		setTitle("Make Block_ComputersButton");
		setSize(500, 600);
		setLayout(new FlowLayout());
		setVisible(true);
		
	}	

	private void displaySQLErrors(SQLException e) 
	{
		errorText.append("\nSQLException: " + e.getMessage() + "\n");
		errorText.append("SQLState:     " + e.getSQLState() + "\n");
		errorText.append("VendorError:  " + e.getErrorCode() + "\n");
	}

	

	public static void main(String[] args) 
	{
		MakeBlock_Computers mks = new MakeBlock_Computers();

		mks.addWindowListener(new WindowAdapter(){
		  public void windowClosing(WindowEvent e) 
		  {
			System.exit(0);
		  }
		});
		
		mks.buildGUI();
	}
}
