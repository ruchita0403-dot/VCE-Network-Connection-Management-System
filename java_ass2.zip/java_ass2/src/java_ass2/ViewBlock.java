package java_ass2;

import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class ViewBlock extends Frame 
{
	Button updateBlockButton;
	List BlockList;
	TextField branchText, bnameText, hodText;
	TextArea errorText;
	Connection connection;
	Statement statement;
	ResultSet rs;
	
	public ViewBlock() 
	{
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectToDB();
	}

	public void connectToDB() 
    {
		try 
		{
		  connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","ruchi","04032001");
		  statement = connection.createStatement();

		} 
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }
	
	private void loadBlock() 
	{	   
		try 
		{
		  rs = statement.executeQuery("SELECT * FROM Block");
		  while (rs.next()) 
		  {
			  BlockList.add(rs.getString("BNAME"));
		  }
		} 
		catch (SQLException e) 
		{ 
		  displaySQLErrors(e);
		}
	}
	
	public void buildGUI() 
	{		
		BlockList = new List(10);
		loadBlock();
		add(BlockList);
		
		//When a list item is selected populate the text fields
		BlockList.addItemListener(new ItemListener()
		{
			public void itemStateChanged(ItemEvent e) 
			{
				try 
				{
					rs = statement.executeQuery("SELECT * FROM Block");
					while (rs.next()) 
					{
						if (rs.getString("BNAME").equals(BlockList.getSelectedItem()))
						break;
					}
					if (!rs.isAfterLast()) 
					{
						bnameText.setText(rs.getString("BNAME"));
						branchText.setText(rs.getString("BRANCH"));
						hodText.setText(rs.getString("HOD"));
					}
				} 
				catch (SQLException selectException) 
				{
					displaySQLErrors(selectException);
				}
			}
		});		
		
	    
		//Handle Update Block Button
		updateBlockButton = new Button("Update Block");
		updateBlockButton.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e) 
			{
				try 
				{
					Statement statement = connection.createStatement();
					int i = statement.executeUpdate("UPDATE Block "
					+ "SET branch ='" + branchText.getText() + "',"
					+ "hod='" + hodText.getText() + "'WHERE bname = '"
					+ BlockList.getSelectedItem()+ "'");
					errorText.append("\nUpdated " + i + " rows successfully");
					BlockList.removeAll();
					loadBlock();
				} 
				catch (SQLException insertException) 
				{
					displaySQLErrors(insertException);
				}
			}
		});
		
		bnameText = new TextField(15);
		bnameText.setEditable(false);
		branchText = new TextField(15);
		hodText = new TextField(15);
		
		errorText = new TextArea(10, 40);
		errorText.setEditable(false);

		Panel first = new Panel();
		first.setLayout(new GridLayout(4, 2));
		first.add(new Label("Block Name:"));
		first.add(bnameText);
		first.add(new Label("Branch:"));
		first.add(branchText);
		first.add(new Label("HOD :"));
		first.add(hodText);
		
		Panel second = new Panel(new GridLayout(4, 1));
		second.add(updateBlockButton);
		
		Panel third = new Panel();
		third.add(errorText);
		
		add(first);
		add(second);
		add(third);
	    
		setTitle("Update Boat");
		setSize(500, 600);
		setLayout(new FlowLayout());
		setVisible(true);
		
	}

	private void displaySQLErrors(SQLException e) 
	{
		errorText.append("\nSQLException: " + e.getMessage() + "\n");
		errorText.append("SQLState:     " + e.getSQLState() + "\n");
		errorText.append("VendorError:  " + e.getErrorCode() + "\n");
	}

	public static void main(String[] args) 
	{
		ViewBlock upb = new ViewBlock();

		upb.addWindowListener(new WindowAdapter(){
		  public void windowClosing(WindowEvent e) 
		  {
			System.exit(0);
		  }
		});
		
		upb.buildGUI();
	}
}
