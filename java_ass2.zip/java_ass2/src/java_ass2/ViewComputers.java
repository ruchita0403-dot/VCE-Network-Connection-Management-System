package java_ass2;

import java.awt.*;
import java.awt.event.*;
import java.sql.*;
public class ViewComputers extends Frame 
{
	Button updateComputersButton;
	List ComputersList;
	TextField cidText, typeText, countText, manufacturerText;
	TextArea errorText;
	Connection connection;
	Statement statement;
	ResultSet rs;
	
	public ViewComputers() 
	{
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectToDB();
	}

	public void connectToDB() 
    {
		try 
		{
		  connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","ruchi","04032001");
		  statement = connection.createStatement();

		} 
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }
	
	private void loadComputers() 
	{	   
		try 
		{
		  rs = statement.executeQuery("SELECT * FROM Computers");
		  while (rs.next()) 
		  {
			  ComputersList.add(rs.getString("CID"));
		  }
		} 
		catch (SQLException e) 
		{ 
		  displaySQLErrors(e);
		}
	}
	
	public void buildGUI() 
	{		
		ComputersList = new List(6);
		loadComputers();
		add(ComputersList);
		
		//When a list item is selected populate the text fields
		ComputersList.addItemListener(new ItemListener()
		{
			public void itemStateChanged(ItemEvent e) 
			{
				try 
				{
					rs = statement.executeQuery("SELECT * FROM Computers");
					while (rs.next()) 
					{
						if (rs.getString("CID").equals(ComputersList.getSelectedItem()))
						break;
					}
					if (!rs.isAfterLast()) 
					{
						cidText.setText(rs.getString("CID"));
						typeText.setText(rs.getString("TYPE"));
						countText.setText(rs.getString("COUNT"));
						manufacturerText.setText(rs.getString("MANUFACTURER"));
					}
				} 
				catch (SQLException selectException) 
				{
					displaySQLErrors(selectException);
				}
			}
		});		
		
	    
		//Handle Update Computers Button
		updateComputersButton = new Button("Update Computers");
		updateComputersButton.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e) 
			{
				try 
				{
					Statement statement = connection.createStatement();
					int i = statement.executeUpdate("UPDATE Computers "
					+ "SET COUNT=" + countText.getText()  
					+ " WHERE cid = '" + ComputersList.getSelectedItem() + "'");
					errorText.append("\nUpdated " + i + " rows successfully");
					ComputersList.removeAll();
					loadComputers();
				} 
				catch (SQLException insertException) 
				{
					displaySQLErrors(insertException);
				}
			}
		});
		
		cidText = new TextField(15);
		cidText.setEditable(false);
		typeText = new TextField(15);
		typeText.setEditable(false);
		countText = new TextField(15);
		manufacturerText = new TextField(15);
		manufacturerText.setEditable(false);

		errorText = new TextArea(10, 40);
		errorText.setEditable(false);

		Panel first = new Panel();
		first.setLayout(new GridLayout(4, 2));
		first.add(new Label("Computer ID:"));
		first.add(cidText);
		first.add(new Label("Type:"));
		first.add(typeText);
		first.add(new Label("Count:"));
		first.add(countText);
		first.add(new Label("Manufacturer:"));
		first.add(manufacturerText);
		
		Panel second = new Panel(new GridLayout(4, 1));
		second.add(updateComputersButton);
		
		Panel third = new Panel();
		third.add(errorText);
		
		add(first);
		add(second);
		add(third);
	    
		setTitle("Update Computers");
		setSize(500, 600);
		setLayout(new FlowLayout());
		setVisible(true);
		
	}

	private void displaySQLErrors(SQLException e) 
	{
		errorText.append("\nSQLException: " + e.getMessage() + "\n");
		errorText.append("SQLState:     " + e.getSQLState() + "\n");
		errorText.append("VendorError:  " + e.getErrorCode() + "\n");
	}

	public static void main(String[] args) 
	{
		ViewComputers upb = new ViewComputers();

		upb.addWindowListener(new WindowAdapter(){
		  public void windowClosing(WindowEvent e) 
		  {
			System.exit(0);
		  }
		});
		
		upb.buildGUI();
	}
}
