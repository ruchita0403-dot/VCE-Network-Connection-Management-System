package java_ass2;

import java.awt.*;
import java.awt.event.*;
import java.sql.*;
public class DeleteOperating_system extends Frame 
{
	Button deleteOperating_systemButton;
	List Operating_systemList;
	TextField osnameText, versionText, vendorText;
	TextArea errorText;
	Connection connection;
	Statement statement;
	ResultSet rs;
	
	public DeleteOperating_system() 
	{
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectToDB();
	}

	public void connectToDB() 
    {
		try 
		{
		  connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","ruchi","04032001");
		  statement = connection.createStatement();

		} 
		catch (SQLException connectException)   
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }
	
	private void loadOperating_system() 
	{	   
		try 
		{
		  rs = statement.executeQuery("SELECT * FROM Operating_system");
		  while (rs.next()) 
		  {
			Operating_systemList.add(rs.getString("osname"));
		  }
		} 
		catch (SQLException e) 
		{ 
		  displaySQLErrors(e);
		}
	}
	
	public void buildGUI() 
	{		
	    Operating_systemList = new List(10);
		loadOperating_system();
		add(Operating_systemList);
		
		//When a list item is selected populate the text fields
		Operating_systemList.addItemListener(new ItemListener()
		{
			public void itemStateChanged(ItemEvent e) 
			{
				try 
				{
					rs = statement.executeQuery("SELECT * FROM Operating_system");
					while (rs.next()) 
					{
						if (rs.getString("osname").equals(Operating_systemList.getSelectedItem()))
						break;
					}
					if (!rs.isAfterLast()) 
					{
						osnameText.setText(rs.getString("osname"));
						versionText.setText(rs.getString("version"));
						vendorText.setText(rs.getString("vendor"));
					}
				} 
				catch (SQLException selectException) 
				{
					displaySQLErrors(selectException);
				}
			}
		});		
		
	    
		//Handle Delete Operating_system Button
		deleteOperating_systemButton = new Button("Delete Operating_system");
		deleteOperating_systemButton.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e) 
			{
				try 
				{
					Statement statement = connection.createStatement();
					int i = statement.executeUpdate("DELETE FROM Operating_system WHERE osname = '" + Operating_systemList.getSelectedItem()+"'");
					errorText.append("\nDeleted " + i + " rows successfully");
					osnameText.setText(null);
					versionText.setText(null);
					vendorText.setText(null);
					Operating_systemList.removeAll();
					loadOperating_system();
				} 
				catch (SQLException insertException) 
				{
					displaySQLErrors(insertException);
				}
			}
		});
		
		osnameText = new TextField(15);
		versionText = new TextField(15);
		vendorText = new TextField(15);
		
		errorText = new TextArea(10, 40);
		errorText.setEditable(false);

		Panel first = new Panel();
		first.setLayout(new GridLayout(4, 2));
		first.add(new Label("Operating sys name:"));
		first.add(osnameText);
		first.add(new Label("Version:"));
		first.add(versionText);
		first.add(new Label("Vendor:"));
		first.add(vendorText);
		
		Panel second = new Panel(new GridLayout(4, 1));
		second.add(deleteOperating_systemButton);
		
		Panel third = new Panel();
		third.add(errorText);
		
		add(first);
		add(second);
		add(third);
	    
		setTitle("Remove Operating_system");
		setSize(450, 600);
		setLayout(new FlowLayout());
		setVisible(true);
		
	}

	

	private void displaySQLErrors(SQLException e) 
	{
		errorText.append("\nSQLException: " + e.getMessage() + "\n");
		errorText.append("SQLState:     " + e.getSQLState() + "\n");
		errorText.append("VendorError:  " + e.getErrorCode() + "\n");
	}

	

	public static void main(String[] args) 
	{
		DeleteOperating_system dels = new DeleteOperating_system();

		dels.addWindowListener(new WindowAdapter(){
		  public void windowClosing(WindowEvent e) 
		  {
			System.exit(0);
		  }
		});
		
		dels.buildGUI();
	}
}
