//Modified
package java_ass2;

import java.awt.*; 
import java.awt.event.*;
import java.sql.*;

public class ViewBlock_Server extends Frame 
{
	Button updateBlock_ServerButton;
	List Block_ServerList;
	TextField ipaddressText, bnameText;
	TextArea errorText;
	Connection connection;
	Statement statement;
	ResultSet rs;
	
	public ViewBlock_Server() 
	{
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectToDB();
	}

	public void connectToDB() 
    {
		try 
		{
		  connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","ruchi","04032001");
		  statement = connection.createStatement();

		} 
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }
	
	private void loadBlock_Server() 
	{	   
		try 
		{
		  rs = statement.executeQuery("SELECT * FROM Block_Server");
		  while (rs.next()) 
		  {
			  Block_ServerList.add(rs.getString("BNAME"));
		  }
		} 
		catch (SQLException e) 
		{ 
		  displaySQLErrors(e);
		}
	}
	
	public void buildGUI() 
	{ 
		Block_ServerList = new List(10);
		loadBlock_Server();
		add(Block_ServerList);
		
		//When a list item is selected populate the text fields
		Block_ServerList.addItemListener(new ItemListener()
		{
			public void itemStateChanged(ItemEvent e) 
			{
				try 
				{
					rs = statement.executeQuery("SELECT * FROM Block_Server");
					while (rs.next()) 
					{
						if (rs.getString("BNAME").equals(Block_ServerList.getSelectedItem()))
						break;
					}
					if (!rs.isAfterLast()) 
					{
						ipaddressText.setText(rs.getString("IPADDRESS"));
						bnameText.setText(rs.getString("BNAME"));
					}
				} 
				catch (SQLException selectException) 
				{
					displaySQLErrors(selectException);
				}
			}
		});		
		
	    
		//Handle Update Sailor Button
		updateBlock_ServerButton = new Button("Update Block_Server");
		updateBlock_ServerButton.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e) 
			{
				try 
				{
					Statement statement = connection.createStatement();
					int i = statement.executeUpdate("UPDATE Block_Server "
					+ "SET ipaddress='" + ipaddressText.getText() + "'"
					+ " WHERE bname = '" + Block_ServerList.getSelectedItem() + "'");
					errorText.append("\nUpdated " + i + " rows successfully");
					Block_ServerList.removeAll();
					loadBlock_Server();
				} 
				catch (SQLException insertException) 
				{
					displaySQLErrors(insertException);
				}
			}
		});
		
		bnameText = new TextField(15);
		bnameText.setEditable(false);
		ipaddressText = new TextField(15);
		
		errorText = new TextArea(10, 40);
		errorText.setEditable(false);

		Panel first = new Panel();
		first.setLayout(new GridLayout(4, 2));
		first.add(new Label("Block Name:"));
		first.add(bnameText);
		first.add(new Label("Ipaddress:"));
		first.add(ipaddressText);
		
		Panel second = new Panel(new GridLayout(4, 1));
		second.add(updateBlock_ServerButton);
		
		Panel third = new Panel();
		third.add(errorText);
		
		add(first);
		add(second);
		add(third);
	    
		setTitle("Update Block_Server");
		setSize(500, 600);
		setLayout(new FlowLayout());
		setVisible(true);
		
	}

	private void displaySQLErrors(SQLException e) 
	{
		errorText.append("\nSQLException: " + e.getMessage() + "\n");
		errorText.append("SQLState:     " + e.getSQLState() + "\n");
		errorText.append("VendorError:  " + e.getErrorCode() + "\n");
	}

	public static void main(String[] args) 
	{
		ViewBlock_Server upb = new ViewBlock_Server();

		upb.addWindowListener(new WindowAdapter(){
		  public void windowClosing(WindowEvent e) 
		  {
			System.exit(0);
		  }
		});
		
		upb.buildGUI();
	}
}
