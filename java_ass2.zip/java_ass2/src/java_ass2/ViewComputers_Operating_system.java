package java_ass2;

import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class ViewComputers_Operating_system extends Frame 
{
	Button updateComputers_Operating_systemButton;
	List Computers_Operating_systemList;
	TextField cidText, osnameText;
	TextArea errorText;
	Connection connection;
	Statement statement;
	ResultSet rs;
	
	public ViewComputers_Operating_system() 
	{
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectToDB();
	}

	public void connectToDB() 
    {
		try 
		{
		  connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","ruchi","04032001");
		  statement = connection.createStatement();

		} 
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }
	
	private void loadComputers_Operating_system() 
	{	   
		try 
		{
		  rs = statement.executeQuery("SELECT * FROM Computers_Operating_system");
		  while (rs.next()) 
		  {
			  Computers_Operating_systemList.add(rs.getString("CID"));
		  }
		} 
		catch (SQLException e) 
		{ 
		  displaySQLErrors(e);
		}
	}
	
	public void buildGUI() 
	{		
		Computers_Operating_systemList = new List(6);
		loadComputers_Operating_system ();
		add(Computers_Operating_systemList);
		
		//When a list item is selected populate the text fields
		Computers_Operating_systemList.addItemListener(new ItemListener()
		{
			public void itemStateChanged(ItemEvent e) 
			{
				try 
				{
					rs = statement.executeQuery("SELECT * FROM Computers_Operating_system");
					while (rs.next()) 
					{
						if (rs.getString("CID").equals(Computers_Operating_systemList.getSelectedItem()))
						break;
					}
					if (!rs.isAfterLast()) 
					{
						cidText.setText(rs.getString("CID"));
						osnameText.setText(rs.getString("OSNAME"));
					}
				} 
				catch (SQLException selectException) 
				{
					displaySQLErrors(selectException);
				}
			}
		});		
		
	    
		//Handle Update Computers_Operating_system Button
		updateComputers_Operating_systemButton = new Button("Update Computers_Operating_system");
		updateComputers_Operating_systemButton.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e) 
			{
				try 
				{
					Statement statement = connection.createStatement();
					int i = statement.executeUpdate("UPDATE Computers_Operating_system "
					+ "SET osname='" + osnameText.getText() + "'"
					+"WHERE cid = '"+ Computers_Operating_systemList.getSelectedItem()+"'");
					errorText.append("\nUpdated " + i + " rows successfully");
					Computers_Operating_systemList.removeAll();
					loadComputers_Operating_system();
				} 
				catch (SQLException insertException) 
				{
					displaySQLErrors(insertException);
				}
			}
		});
		
		cidText = new TextField(15);
		cidText.setEditable(false);
		osnameText = new TextField(15);
		
		errorText = new TextArea(10, 40);
		errorText.setEditable(false);

		Panel first = new Panel();
		first.setLayout(new GridLayout(4, 2));
		first.add(new Label("Computer ID:"));
		first.add(cidText);
		first.add(new Label("Operating_system_Name:"));
		first.add(osnameText);
		
		Panel second = new Panel(new GridLayout(4, 1));
		second.add(updateComputers_Operating_systemButton);
		
		Panel third = new Panel();
		third.add(errorText);
		
		add(first);
		add(second);
		add(third);
	    
		setTitle("Update Boat");
		setSize(500, 600);
		setLayout(new FlowLayout());
		setVisible(true);
		
	}

	private void displaySQLErrors(SQLException e) 
	{
		errorText.append("\nSQLException: " + e.getMessage() + "\n");
		errorText.append("SQLState:     " + e.getSQLState() + "\n");
		errorText.append("VendorError:  " + e.getErrorCode() + "\n");
	}

	public static void main(String[] args) 
	{
		ViewComputers_Operating_system upb = new ViewComputers_Operating_system();

		upb.addWindowListener(new WindowAdapter(){
		  public void windowClosing(WindowEvent e) 
		  {
			System.exit(0);
		  }
		});
		
		upb.buildGUI();
	}
}
