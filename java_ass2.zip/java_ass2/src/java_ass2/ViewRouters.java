package java_ass2;

import java.awt.*;
import java.awt.event.*;
import java.sql.*;
public class ViewRouters extends Frame 
{
	Button updateRoutersButton;
	List RoutersList;
	TextField  websiteText, speedText, usernameText, companyText;
	TextArea errorText;
	Connection connection;
	Statement statement;
	ResultSet rs;
	
	public ViewRouters() 
	{
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectToDB();
	}

	public void connectToDB() 
    {
		try 
		{
		  connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","ruchi","04032001");
		  statement = connection.createStatement();

		} 
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }
	
	private void loadRouters() 
	{	   
		try 
		{
		  rs = statement.executeQuery("SELECT * FROM Routers");
		  while (rs.next()) 
		  {
			  RoutersList.add(rs.getString("WEBSITE"));
		  }
		} 
		catch (SQLException e) 
		{ 
		  displaySQLErrors(e);
		}
	}
	
	public void buildGUI() 
	{		
		RoutersList = new List(6);
		loadRouters();
		add(RoutersList);
		
		//When a list item is selected populate the text fields
		RoutersList.addItemListener(new ItemListener()
		{
			public void itemStateChanged(ItemEvent e) 
			{
				try 
				{
					rs = statement.executeQuery("SELECT * FROM Routers");
					while (rs.next()) 
					{
						if (rs.getString("website").equals(RoutersList.getSelectedItem()))
						break;
					}
					if (!rs.isAfterLast()) 
					{
						websiteText.setText(rs.getString("website"));
						speedText.setText(rs.getString("speed"));
						usernameText.setText(rs.getString("USERNAME"));
						companyText.setText(rs.getString("COMPANY"));
					}
				} 
				catch (SQLException selectException) 
				{
					displaySQLErrors(selectException);
				}
			}
		});		
		
	    
		//Handle Update Routers Button
		updateRoutersButton = new Button("Update Routers");
		updateRoutersButton.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e) 
			{
				try 
				{
					Statement statement = connection.createStatement();
					int i = statement.executeUpdate("UPDATE Routers "
					+ "SET SPEED='" + speedText.getText() + "', "
					+ "USERNAME= '" + usernameText.getText() + "'," 
					+" COMPANY = '" +companyText.getText() + "' WHERE website = '"
					+ RoutersList.getSelectedItem() + "'");
					errorText.append("\nUpdated " + i + " rows successfully");
					RoutersList.removeAll();
					loadRouters();
				} 
				catch (SQLException insertException) 
				{
					displaySQLErrors(insertException);
				}
			}
		});
		
		websiteText = new TextField(15);
		websiteText.setEditable(false);
		speedText = new TextField(15);
		usernameText = new TextField(15);
		companyText = new TextField(15);
		
		errorText = new TextArea(10, 40);
		errorText.setEditable(false);

		Panel first = new Panel();
		first.setLayout(new GridLayout(4, 2));
		first.add(new Label("Website:"));
		first.add(websiteText);
		first.add(new Label("Speed:"));
		first.add(speedText);
		first.add(new Label("Username:"));
		first.add(usernameText);
		first.add(new Label("Company:"));
		first.add(companyText);
		
		Panel second = new Panel(new GridLayout(4, 1));
		second.add(updateRoutersButton);
		
		Panel third = new Panel();
		third.add(errorText);
		
		add(first);
		add(second);
		add(third);
	    
		setTitle("Update Routers");
		setSize(500, 600);
		setLayout(new FlowLayout());
		setVisible(true);
		
	}

	private void displaySQLErrors(SQLException e) 
	{
		errorText.append("\nSQLException: " + e.getMessage() + "\n");
		errorText.append("SQLState:     " + e.getSQLState() + "\n");
		errorText.append("VendorError:  " + e.getErrorCode() + "\n");
	}

	public static void main(String[] args) 
	{
		ViewRouters upb = new ViewRouters();

		upb.addWindowListener(new WindowAdapter(){
		  public void windowClosing(WindowEvent e) 
		  {
			System.exit(0);
		  }
		});
		
		upb.buildGUI();
	}
}
