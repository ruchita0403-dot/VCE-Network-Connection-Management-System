package java_ass2;

import java.awt.*;
import java.awt.event.*;
import java.sql.*;

import javax.swing.JOptionPane;
public class InsertComputers extends Frame 
{
	Button insertComputersButton;
	TextField cidText, typeText, countText, manufacturerText;
	TextArea errorText;
	Connection connection;
	Statement statement;
	public InsertComputers() 
	{
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectToDB();
	}

	public void connectToDB() 
    {
		try 
		{
		  connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","ruchi","04032001");
		  statement = connection.createStatement();

		} 
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }
	public void buildGUI() 
	{		
		//Handle Insert Computers Button
		insertComputersButton = new Button("Insert Computers");
		insertComputersButton.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent e) 
			{
				try 
				{
				  String query= "INSERT INTO Computers VALUES('" + cidText.getText() + "', " + "'" + typeText.getText() + "'," + countText.getText() + ",'" + manufacturerText.getText() + "')";
				  int i = statement.executeUpdate(query);
				  errorText.append("\nInserted " + i + " rows successfully");
				} 
				catch(SQLSyntaxErrorException syntax)
				{  
			        JOptionPane.showMessageDialog(null,"Please enter the correct data type",
						      "ERROR", JOptionPane.ERROR_MESSAGE);
				}
				catch (SQLException insertException) 
				{
				  displaySQLErrors(insertException);
				}
			}
		});

	
		cidText = new TextField(15);
		typeText = new TextField(15);
		countText = new TextField(15);
		manufacturerText = new TextField(15);

		
		errorText = new TextArea(10, 40);
		errorText.setEditable(false);

		Panel first = new Panel();
		first.setLayout(new GridLayout(4, 2));
		first.add(new Label("Computer ID:"));
		first.add(cidText);
		first.add(new Label("Type:"));
		first.add(typeText);
		first.add(new Label("Count:"));
		first.add(countText);
		first.add(new Label("Manufacturer:"));
		first.add(manufacturerText);
		first.setBounds(125,90,200,100);
		
		Panel second = new Panel(new GridLayout(4, 1));
		second.add(insertComputersButton);
        second.setBounds(125,220,150,100);         
		
		Panel third = new Panel();
		third.add(errorText);
		third.setBounds(125,320,300,200);
		
		setLayout(null);

		add(first);
		add(second);
		add(third);
	    
		setTitle("New Computers Creation");
		setSize(500, 600);
		setVisible(true);
	}

	

	private void displaySQLErrors(SQLException e) 
	{
		System.out.println(e);
		errorText.append("\nSQLException: " + e.getMessage() + "\n");
		errorText.append("SQLState:     " + e.getSQLState() + "\n");
		errorText.append("VendorError:  " + e.getErrorCode() + "\n");
	}

	

	public static void main(String[] args) 
	{
		InsertComputers sail = new InsertComputers();

		sail.addWindowListener(new WindowAdapter(){
		  public void windowClosing(WindowEvent e) 
		  {
			System.exit(0);
		  }
		});
		
		sail.buildGUI();
	}
}
