package java_ass2;

import java.awt.*;
import java.awt.event.*;
import java.sql.*;
public class DeleteInternet extends Frame 
{
	Button deleteInternetButton;
	List InternetList;
	TextField macText, htmlText, ser_providerText;
	TextArea errorText;
	Connection connection;
	Statement statement;
	ResultSet rs;
	
	public DeleteInternet() 
	{
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectToDB();
	}

	public void connectToDB() 
    {
		try 
		{
		  connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","ruchi","04032001");
		  statement = connection.createStatement();

		} 
		catch (SQLException connectException)   
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }
	
	private void loadInternet() 
	{	   
		try 
		{
		  rs = statement.executeQuery("SELECT * FROM Internet");
		  while (rs.next()) 
		  {
			  InternetList.add(rs.getString("mac_address"));
		  }
		} 
		catch (SQLException e) 
		{ 
		  displaySQLErrors(e);
		}
	}
	
	public void buildGUI() 
	{		
		InternetList = new List(10);
		loadInternet();
		add(InternetList);
		
		//When a list item is selected populate the text fields
		InternetList.addItemListener(new ItemListener()
		{
			public void itemStateChanged(ItemEvent e) 
			{
				try 
				{
					rs = statement.executeQuery("SELECT * FROM Internet");
					while (rs.next()) 
					{
						if (rs.getString("mac_address").equals(InternetList.getSelectedItem()))
						break;
					}
					if (!rs.isAfterLast()) 
					{
						macText.setText(rs.getString("mac_address"));
						htmlText.setText(rs.getString("html"));
						ser_providerText.setText(rs.getString("serv_provider"));
					}
				} 
				catch (SQLException selectException) 
				{
					displaySQLErrors(selectException);
				}
			}
		});		
		
	    
		//Handle Delete Internet Button
		deleteInternetButton = new Button("Delete Internet");
		deleteInternetButton.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e) 
			{
				try 
				{
					Statement statement = connection.createStatement();
					int i = statement.executeUpdate("DELETE FROM Internet WHERE MAC_ADDRESS = '" + InternetList.getSelectedItem()+"'");
					errorText.append("\nDeleted " + i + " rows successfully");
					macText.setText(null);
					htmlText.setText(null);
					ser_providerText.setText(null);
					InternetList.removeAll();
					loadInternet();
				} 
				catch (SQLException insertException) 
				{
					displaySQLErrors(insertException);
				}
			}
		});
		
		macText = new TextField(15);
		htmlText = new TextField(15);
		ser_providerText = new TextField(15);
		
		errorText = new TextArea(10, 40);
		errorText.setEditable(false);

		Panel first = new Panel();
		first.setLayout(new GridLayout(4, 2));
		first.add(new Label("Mac_Address:"));
		first.add(macText);
		first.add(new Label("Html:"));
		first.add(htmlText);
		first.add(new Label("Service_provider:"));
		first.add(ser_providerText);
		
		Panel second = new Panel(new GridLayout(4, 1));
		second.add(deleteInternetButton);
		
		Panel third = new Panel();
		third.add(errorText);
		
		add(first);
		add(second);
		add(third);
	    
		setTitle("Remove Internet");
		setSize(450, 600);
		setLayout(new FlowLayout());
		setVisible(true);
		
	}

	

	private void displaySQLErrors(SQLException e) 
	{
		errorText.append("\nSQLException: " + e.getMessage() + "\n");
		errorText.append("SQLState:     " + e.getSQLState() + "\n");
		errorText.append("VendorError:  " + e.getErrorCode() + "\n");
	}

	

	public static void main(String[] args) 
	{
		DeleteInternet dels = new DeleteInternet();

		dels.addWindowListener(new WindowAdapter(){
		  public void windowClosing(WindowEvent e) 
		  {
			System.exit(0);
		  }
		});
		
		dels.buildGUI();
	}
}
