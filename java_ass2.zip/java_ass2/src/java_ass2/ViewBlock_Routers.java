package java_ass2;

import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class ViewBlock_Routers extends Frame 
{
	Button updateBlock_RoutersButton;
	List Block_RoutersList;
	TextField websiteText, bnameText;
	TextArea errorText;
	Connection connection;
	Statement statement;
	ResultSet rs;
	
	public ViewBlock_Routers() 
	{
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectToDB();
	}

	public void connectToDB() 
    {
		try 
		{
		  connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","ruchi","04032001");
		  statement = connection.createStatement();

		} 
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }
	
	private void loadBlock_Routers() 
	{	   
		try 
		{
		  rs = statement.executeQuery("SELECT * FROM Block_Routers");
		  while (rs.next()) 
		  {
			  Block_RoutersList.add(rs.getString("BNAME"));
		  }
		} 
		catch (SQLException e) 
		{ 
		  displaySQLErrors(e);
		}
	}
	
	public void buildGUI() 
	{		
		Block_RoutersList = new List(6);
		loadBlock_Routers();
		add(Block_RoutersList);
		
		//When a list item is selected populate the text fields
		Block_RoutersList.addItemListener(new ItemListener()
		{
			public void itemStateChanged(ItemEvent e) 
			{
				try 
				{
					rs = statement.executeQuery("SELECT * FROM Block_Routers");
					while (rs.next()) 
					{
						if (rs.getString("BNAME").equals(Block_RoutersList.getSelectedItem()))
						break;
					}
					if (!rs.isAfterLast()) 
					{
						websiteText.setText(rs.getString("WEBSITE"));
						bnameText.setText(rs.getString("BNAME"));
					}
				} 
				catch (SQLException selectException) 
				{
					displaySQLErrors(selectException);
				}
			}
		});		
		
	    
		//Handle Update Block_Routers Button
		updateBlock_RoutersButton = new Button("Update Block_Routers");
		updateBlock_RoutersButton.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e) 
			{
				try 
				{
					Statement statement = connection.createStatement();
					int i = statement.executeUpdate("UPDATE Block_Routers "
					+ "SET website='" + websiteText.getText() + "'"
							+ "WHERE bname = '"	+ Block_RoutersList.getSelectedItem()+"'");
					errorText.append("\nUpdated " + i + " rows successfully");
					Block_RoutersList.removeAll();
					loadBlock_Routers();
				} 
				catch (SQLException insertException) 
				{
					displaySQLErrors(insertException);
				}
			}
		});
		
		
		websiteText = new TextField(15);
		bnameText = new TextField(15);
		
		errorText = new TextArea(10, 40);
		errorText.setEditable(false);

		Panel first = new Panel();
		first.setLayout(new GridLayout(4, 2));
		first.add(new Label("Block Name:"));
		first.add(bnameText);
		first.add(new Label("Website :"));
		first.add(websiteText);
		
		Panel second = new Panel(new GridLayout(4, 1));
		second.add(updateBlock_RoutersButton);
		
		Panel third = new Panel();
		third.add(errorText);
		
		add(first);
		add(second);
		add(third);
	    
		setTitle("Update Block_Routers");
		setSize(500, 600);
		setLayout(new FlowLayout());
		setVisible(true);
		
	}

	private void displaySQLErrors(SQLException e) 
	{
		errorText.append("\nSQLException: " + e.getMessage() + "\n");
		errorText.append("SQLState:     " + e.getSQLState() + "\n");
		errorText.append("VendorError:  " + e.getErrorCode() + "\n");
	}

	public static void main(String[] args) 
	{
		ViewBlock_Routers upb = new ViewBlock_Routers();

		upb.addWindowListener(new WindowAdapter(){
		  public void windowClosing(WindowEvent e) 
		  {
			System.exit(0);
		  }
		});
		
		upb.buildGUI();
	}
}
