package java_ass2;

import java.awt.*;
import java.awt.event.*;
import java.sql.*;
public class DeleteServer extends Frame 
{
	Button deleteServerButton;
	List ServerList;
	TextField ipaddressText;
	TextArea errorText;
	Connection connection;
	Statement statement;
	ResultSet rs;
	
	public DeleteServer() 
	{
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectToDB();
	}

	public void connectToDB() 
    {
		try 
		{
		  connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","ruchi","04032001");
		  statement = connection.createStatement();

		} 
		catch (SQLException connectException)   
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }
	
	private void loadServer() 
	{	   
		try 
		{
		  rs = statement.executeQuery("SELECT * FROM Server");
		  while (rs.next()) 
		  {
			  ServerList.add(rs.getString("IPADDRESS"));
		  }
		} 
		catch (SQLException e) 
		{ 
		  displaySQLErrors(e);
		}
	}
	
	public void buildGUI() 
	{		
		ServerList = new List(10);
		loadServer();
		add(ServerList);
		
		//When a list item is selected populate the text fields
		ServerList.addItemListener(new ItemListener()
		{
			public void itemStateChanged(ItemEvent e) 
			{
				try 
				{
					rs = statement.executeQuery("SELECT * FROM Server");
					while (rs.next()) 
					{
						if (rs.getString("IPADDRESS").equals(ServerList.getSelectedItem()))
						break;
					}
					if (!rs.isAfterLast()) 
					{
						ipaddressText.setText(rs.getString("IPADDRESS"));
					}
				} 
				catch (SQLException selectException) 
				{
					displaySQLErrors(selectException);
				}
			}
		});		
		
	    
		//Handle Delete Server Button
		deleteServerButton = new Button("Delete Server");
		deleteServerButton.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e) 
			{
				try 
				{
					Statement statement = connection.createStatement();
					int i = statement.executeUpdate("DELETE FROM Server WHERE ipaddress ='" + ServerList.getSelectedItem()+"'");
					errorText.append("\nDeleted " + i + " rows successfully");
					ipaddressText.setText(null);
					ServerList.removeAll();
					loadServer();
				} 
				catch (SQLException insertException) 
				{
					displaySQLErrors(insertException);
				}
			}
		});
		
		ipaddressText = new TextField(15);
		
		errorText = new TextArea(10, 40);
		errorText.setEditable(false);

		Panel first = new Panel();
		first.setLayout(new GridLayout(4, 2));
		first.add(new Label("IPADDRESS:"));
		first.add(ipaddressText);
		
		Panel second = new Panel(new GridLayout(4, 1));
		second.add(deleteServerButton);
		
		Panel third = new Panel();
		third.add(errorText);
		
		add(first);
		add(second);
		add(third);
	    
		setTitle("Remove Server");
		setSize(450, 600);
		setLayout(new FlowLayout());
		setVisible(true);
		
	}

	

	private void displaySQLErrors(SQLException e) 
	{
		errorText.append("\nSQLException: " + e.getMessage() + "\n");
		errorText.append("SQLState:     " + e.getSQLState() + "\n");
		errorText.append("VendorError:  " + e.getErrorCode() + "\n");
	}

	

	public static void main(String[] args) 
	{
		DeleteServer dels = new DeleteServer();

		dels.addWindowListener(new WindowAdapter(){
		  public void windowClosing(WindowEvent e) 
		  {
			System.exit(0);
		  }
		});
		
		dels.buildGUI();
	}
}
